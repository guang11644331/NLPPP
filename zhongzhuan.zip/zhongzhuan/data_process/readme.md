### 数据格式：
id  src tgt

1.先用dataset处理成pickle

2.再用process_data处理成pkl

___
1.sighan系列数据先用trainset，和testset处理

2.build_lbl: 构建lable

3.用dataset处理成pickle

4.再用process_data处理成pkl